package com.animal;
public class Animal
{
      String name;
      String species;
      int age;
      public Animal(String name,int age,String species)
      {
         this.name=name;
         this.age=age;
         this.species=species;
      }
}
