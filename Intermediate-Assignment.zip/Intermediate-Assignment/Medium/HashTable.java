import java.util.Scanner;
class DLLNode
{
    DLLNode next, prev;
    int data;
    public DLLNode(int x)
    {
        data = x;
        next = null;
        prev = null;
    }
}
class OutputHashTable
{
    DLLNode[] table;
    int size ,initialCapacity=11;
    float loadFactor=0.75f;
    public OutputHashTable(int tableSize)
    {
        table = new DLLNode[tableSize];
        size = 0;
    }
    public void insert(int val)
    {
        size++;
        int pos = myhash(val);        
        DLLNode newnode=new DLLNode(val);
        DLLNode start = table[pos];                
        if (table[pos] == null)
            table[pos] = newnode;            
        else
        {
            newnode.next = start;
            start.prev = newnode;
            table[pos] = newnode;
        } 
        if (size / initialCapacity >= loadFactor) {
            rehash();
        }   
    }
    private void rehash() 
    {
        int newCapacity = initialCapacity * 2;
        table = new DLLNode[newCapacity];
        DLLNode start = table[pos];                
        if (table[pos] == null)
            table[pos] = newnode;            
        else
        {
            newnode.next = start;
            start.prev = newnode;
            table[pos] = newnode;
        }
        initialCapacity = newCapacity;
    }
    public void remove(int val)
    {
        try
        {
            int pos = myhash(val);    
            DLLNode start = table[pos];
            DLLNode end = start;
            if (start.data == val)
            {
                size--;
                if (start.next == null)
                {
                    table[pos] = null;
                    return;
                }                
                start = start.next;
                start.prev = null;
                table[pos] = start;
                return;
            }
 
            while (end.next != null && end.next.data != val)
                end = end.next;
            if (end.next == null)
            {
                System.out.println("\nElement not found\n");
                return;
            }
            size--;
            if (end.next.next == null)
            {
                end.next = null;
                return;
            }
            end.next.next.prev = end;
            end.next = end.next.next;
 
            table[pos] = start;
        }
        catch (Exception e)
        {
            System.out.println("\nElement not found\n");
        }
    }
    private int myhash(Integer x )
    {
        int hashVal = x.hashCode( );
        hashVal %= table.length;
        if (hashVal < 0)
            hashVal += table.length;
        return hashVal;
    }
    public void printHashTable ()
    {
        System.out.println();
        for (int i = 0; i < table.length; i++)
        {
            System.out.print ("Bucket " + i + ":  ");            
 
            DLLNode start = table[i];
            while(start != null)
            {
                System.out.print(start.data +" ");
                start = start.next;
            }
            System.out.println();
        }
    }
}
public class HashTable
{ 
    public static void main(String[] args) 
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("Hash Table Test\n\n");
        System.out.println("Enter size");
        OutputHashTable ht = new OutputHashTable(scan.nextInt() );
        while(true)   
        {
            System.out.println("\nHash Table Operations\n");
            System.out.println("1. insert ");
            System.out.println("2. remove");
            //System.out.println("3. search");
            System.out.println("4. display");
            System.out.println("5. exit");
            int choice = scan.nextInt();             
            switch (choice)
            {
            case 1 : 
                System.out.println("Enter integer element to insert");
                ht.insert( scan.nextInt() ); 
                break;                          
            case 2 :                  
                System.out.println("Enter integer element to delete");
                ht.remove( scan.nextInt() ); 
                break;
           /* case 3:
                System.out.println("Enter the element to search");
                System.out.println(search(scan.nextInt()));*/
            case 4:
                ht.printHashTable();
                break; 
            case 5:
                System.exit(0);       
            default : 
                System.out.println("Wrong Entry \n ");
                break;   
            }  
             
       }
    /*OutputHashTable search(int key)
    {
         while(ht.get(key)!=null)
         {
            if(ht.get(key)==key)
            {
               return ht.get(key);
            }
         }
         return null;
    }*/
    }
 
}
