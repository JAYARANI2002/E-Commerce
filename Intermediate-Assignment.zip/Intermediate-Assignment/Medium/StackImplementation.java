//Stack implementation using LinkedList
import static java.lang.System.exit;
import java.util.Scanner;
class StackUsingLinkedlist {

    private class Node {

        int data;
        Node link; 
    }

    Node top;

    StackUsingLinkedlist()
    {
        this.top = null;
    }

    // Using this function we will be pushing elements into the stack
    public void push(int x) 
    {

        Node temp = new Node();

        if (temp == null) {
            System.out.print("\nHeap Overflow");
            return;
        }

        temp.data = x;

        temp.link = top;

        top = temp;
    }

    // Using this function we will be checking whether the stack is empty or not
    public boolean isEmpty()
    {
        return top == null;
    }

    // using this function we will return the top element of the stack
    public int peek()
    {

        if (!isEmpty()) {
            return top.data;
        }
        else {
            System.out.println("Stack is empty");
            return -1;
        }
    }

    // Using this function we will pop the top element of the stack
    public void pop() 
    {

        if (top == null) {
            System.out.print("\nStack Underflow");
            return;
        }

        top = (top).link;
    }

    // this function will be used to display the items of the stack
    public void display()
    {

        if (top == null) {
            System.out.printf("\nStack Underflow");
            exit(1);
        }
        else {
            Node temp = top;
            while (temp != null) {

                System.out.printf("%d->", temp.data);

                temp = temp.link;
            }
        }
    }
}

class StackImplementation {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        StackUsingLinkedlist stk = new StackUsingLinkedlist();
        System.out.println("Select the operation");
        System.out.println(" 1. Add the element in the stack");
        System.out.println(" 2. display the stack");
        System.out.println(" 3. Top of the element");
        System.out.println(" 4. check stack is empty or not");
        System.out.println(" 5. delete the top ");
        System.out.println(" 6. Exit");
        while(true)
        {
           int n=sc.nextInt();
           switch(n)
           { 
              case 1:
              {
                System.out.println("add a element");
                int element=sc.nextInt();
                stk.push(element);
                break;
              }
              case 2:
              {
                stk.display();break;
              }
              case 3:stk.display();break;
              case 4:stk.peek();break;
              case 5:stk.pop();break;
              case 6:System.exit(0);
              default:System.out.println("Give correct number");
           }
        }
    }
}
