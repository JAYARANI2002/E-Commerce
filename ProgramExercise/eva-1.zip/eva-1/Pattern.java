import java.util.Scanner;
default class Pattern
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println((char)n);
		for(int i=n;i>=0;i--)
		{
			for(int j=1;j<=i;j++)
			{
			     System.out.print(j+"");
		        }
			System.out.println();
		}
		 for(int i=1;i<=n;i++)
                {
                        for(int j=1;j<=i;j++)
                        {
                             System.out.print(j+"");
                        }
                        System.out.println();
                }
                main(1);

	}
	public static void main(int a)
	{
             int array[][]={{1,2,3},{1,2,3}};
             int rowlength=array[0].length;
             int collength=array[0].length;
             System.out.println(rowlength+" "+collength);
     	}
}

