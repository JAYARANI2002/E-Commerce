import java.io.*;
public class Example1
{
   public static void main(String args[])throws Exception
   {
       //Thread t=new Thread();
      // t.setDaemon(true);
      // t.start();
      // t.sleep(1000);
       System.out.println(Thread.currentThread().isDaemon());
       //t.wait();
   }
}  
